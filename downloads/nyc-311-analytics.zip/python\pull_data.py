"""
Pull NYC 311 Service Requests from the NYC Open Data (Socrata SODA) API.

Dataset: "311 Service Requests from 2010 to Present"  (id: erm2-nwe9)
Docs:    https://data.cityofnewyork.us/resource/erm2-nwe9

Examples
    python python/pull_data.py                                  # default window
    python python/pull_data.py --start 2025-01-01 --end 2025-07-01 --max-rows 1500000

Optional: set SOCRATA_APP_TOKEN (free, from data.cityofnewyork.us) for higher rate limits.
"""
import argparse
import csv
import os
import sys
import time
from pathlib import Path

import requests

BASE_URL = "https://data.cityofnewyork.us/resource/erm2-nwe9.json"

FIELDS = [
    "unique_key", "created_date", "closed_date", "agency", "agency_name",
    "complaint_type", "descriptor", "location_type", "incident_zip", "borough",
    "community_board", "status", "resolution_description", "open_data_channel_type",
    "latitude", "longitude",
]


def fetch_page(session, params, retries=5):
    for attempt in range(1, retries + 1):
        try:
            r = session.get(BASE_URL, params=params, timeout=120)
            if r.status_code == 200:
                return r.json()
            print(f"  HTTP {r.status_code}, retry {attempt}/{retries}", file=sys.stderr)
        except requests.RequestException as e:
            print(f"  {e!r}, retry {attempt}/{retries}", file=sys.stderr)
        time.sleep(2 * attempt)
    raise RuntimeError("API kept failing; try again later or use a smaller date range.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("--start", default="2025-01-01", help="created_date >= this (YYYY-MM-DD)")
    ap.add_argument("--end", default="2025-04-01", help="created_date <  this (YYYY-MM-DD)")
    ap.add_argument("--max-rows", type=int, default=1_000_000)
    ap.add_argument("--page-size", type=int, default=50_000)
    ap.add_argument("--out", default="data/raw/nyc311_raw.csv")
    args = ap.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    session = requests.Session()
    token = os.environ.get("SOCRATA_APP_TOKEN")
    if token:
        session.headers["X-App-Token"] = token

    where = (f"created_date >= '{args.start}T00:00:00' "
             f"AND created_date < '{args.end}T00:00:00'")
    total, offset = 0, 0

    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        while total < args.max_rows:
            limit = min(args.page_size, args.max_rows - total)
            params = {
                "$select": ",".join(FIELDS),
                "$where": where,
                "$order": "created_date,unique_key",
                "$limit": limit,
                "$offset": offset,
            }
            rows = fetch_page(session, params)
            if not rows:
                break
            writer.writerows(rows)
            total += len(rows)
            offset += len(rows)
            print(f"  {total:,} rows downloaded...")
            if len(rows) < limit:
                break

    print(f"Done: {total:,} rows -> {out}")
    if total >= args.max_rows:
        print("Note: stopped at --max-rows. Raise it or narrow --start/--end if you need the full window.")


if __name__ == "__main__":
    main()
