-- =====================================================================
-- NYC 311 analysis queries (PostgreSQL). Each answers a business question.
-- =====================================================================

-- Q1. Which complaint types drive the most volume, and what share is that?
SELECT c.complaint_type,
       COUNT(*)                                                   AS requests,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)         AS pct_of_total,
       ROUND(100.0 * SUM(COUNT(*)) OVER (ORDER BY COUNT(*) DESC)
                   / SUM(COUNT(*)) OVER (), 2)                    AS cumulative_pct
FROM fact_requests f
JOIN dim_complaint c USING (complaint_key)
GROUP BY c.complaint_type
ORDER BY requests DESC
LIMIT 15;

-- Q2. Agency performance: how fast do they close requests? (median and p90, not just average)
SELECT a.agency,
       COUNT(*)                                                              AS closed_requests,
       ROUND(AVG(f.response_hours), 1)                                       AS avg_hours,
       ROUND((PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY f.response_hours))::NUMERIC, 1) AS median_hours,
       ROUND((PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY f.response_hours))::NUMERIC, 1) AS p90_hours
FROM fact_requests f
JOIN dim_agency a USING (agency_key)
WHERE f.response_hours IS NOT NULL
GROUP BY a.agency
HAVING COUNT(*) >= 1000
ORDER BY median_hours DESC;

-- Q3. Monthly volume with month-over-month change and a 3-month rolling average
WITH monthly AS (
    SELECT d.year, d.month, MIN(d.full_date) AS month_start, COUNT(*) AS requests
    FROM fact_requests f
    JOIN dim_date d USING (date_key)
    GROUP BY d.year, d.month
)
SELECT month_start,
       requests,
       ROUND(100.0 * (requests - LAG(requests) OVER w) / NULLIF(LAG(requests) OVER w, 0), 1) AS mom_pct_change,
       ROUND(AVG(requests) OVER (ORDER BY month_start ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 0) AS rolling_3m_avg
FROM monthly
WINDOW w AS (ORDER BY month_start)
ORDER BY month_start;

-- Q4. Top 3 complaint types inside each borough (ROW_NUMBER inside a CTE)
WITH ranked AS (
    SELECT l.borough,
           c.complaint_type,
           COUNT(*) AS requests,
           ROW_NUMBER() OVER (PARTITION BY l.borough ORDER BY COUNT(*) DESC) AS rn
    FROM fact_requests f
    JOIN dim_location  l USING (location_key)
    JOIN dim_complaint c USING (complaint_key)
    WHERE l.borough <> 'Unknown'
    GROUP BY l.borough, c.complaint_type
)
SELECT borough, rn AS rank, complaint_type, requests
FROM ranked
WHERE rn <= 3
ORDER BY borough, rn;

-- Q5. SLA view: share of closed requests that took longer than 72 hours, by agency
SELECT a.agency,
       COUNT(*) AS closed_requests,
       COUNT(*) FILTER (WHERE f.response_hours > 72) AS over_72h,
       ROUND(100.0 * COUNT(*) FILTER (WHERE f.response_hours > 72) / COUNT(*), 1) AS pct_over_72h
FROM fact_requests f
JOIN dim_agency a USING (agency_key)
WHERE f.response_hours IS NOT NULL
GROUP BY a.agency
HAVING COUNT(*) >= 1000
ORDER BY pct_over_72h DESC;

-- Q6. When do noise complaints happen? (day of week x hour of day)
SELECT d.iso_dow, d.day_name,
       EXTRACT(HOUR FROM f.created_ts)::INT AS hour_of_day,
       COUNT(*) AS requests
FROM fact_requests f
JOIN dim_date d      USING (date_key)
JOIN dim_complaint c USING (complaint_key)
WHERE c.complaint_type ILIKE 'noise%'
GROUP BY d.iso_dow, d.day_name, hour_of_day
ORDER BY d.iso_dow, hour_of_day;

-- Q7. Open backlog by agency and age bucket (age measured as of the newest record in the data)
WITH as_of AS (SELECT MAX(created_ts) AS ts FROM fact_requests)
SELECT a.agency,
       COUNT(*) AS open_requests,
       COUNT(*) FILTER (WHERE f.created_ts >= o.ts - INTERVAL '7 days')                                        AS age_0_7d,
       COUNT(*) FILTER (WHERE f.created_ts <  o.ts - INTERVAL '7 days'  AND f.created_ts >= o.ts - INTERVAL '30 days')                  AS age_8_30d,
       COUNT(*) FILTER (WHERE f.created_ts <  o.ts - INTERVAL '30 days')                                                                AS age_30d_plus
FROM fact_requests f
JOIN dim_agency a USING (agency_key)
CROSS JOIN as_of o
WHERE NOT f.is_closed
GROUP BY a.agency
ORDER BY open_requests DESC
LIMIT 15;

-- Q8. Which channel (phone, online, mobile...) is growing? Share of volume per month.
WITH by_month AS (
    SELECT date_trunc('month', f.created_ts)::DATE AS month_start,
           ch.channel,
           COUNT(*) AS requests
    FROM fact_requests f
    JOIN dim_channel ch USING (channel_key)
    GROUP BY 1, ch.channel
)
SELECT month_start,
       channel,
       requests,
       ROUND(100.0 * requests / SUM(requests) OVER (PARTITION BY month_start), 1) AS pct_of_month
FROM by_month
ORDER BY month_start, requests DESC;
