-- Star schema built from stg_311.
-- Run order: 01_staging.sql -> load CSV -> 02_star_schema.sql -> 03_analysis.sql
DROP TABLE IF EXISTS fact_requests, dim_date, dim_agency, dim_complaint, dim_location, dim_channel CASCADE;

-- ---------- Dimensions ----------
CREATE TABLE dim_date AS
SELECT
    to_char(d, 'YYYYMMDD')::INT        AS date_key,
    d::DATE                            AS full_date,
    EXTRACT(YEAR    FROM d)::INT       AS year,
    EXTRACT(QUARTER FROM d)::INT       AS quarter,
    EXTRACT(MONTH   FROM d)::INT       AS month,
    to_char(d, 'Mon')                  AS month_name,
    EXTRACT(ISODOW  FROM d)::INT       AS iso_dow,        -- 1 = Mon ... 7 = Sun
    to_char(d, 'Dy')                   AS day_name,
    EXTRACT(ISODOW  FROM d) >= 6       AS is_weekend
FROM generate_series(
        (SELECT date_trunc('year', MIN(created_date)) FROM stg_311),
        (SELECT date_trunc('year', MAX(created_date)) + INTERVAL '1 year' - INTERVAL '1 day' FROM stg_311),
        INTERVAL '1 day') AS g(d);
ALTER TABLE dim_date ADD PRIMARY KEY (date_key);

CREATE TABLE dim_agency (
    agency_key  INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    agency      TEXT NOT NULL,
    agency_name TEXT NOT NULL,
    UNIQUE (agency, agency_name)
);
INSERT INTO dim_agency (agency, agency_name)
SELECT DISTINCT agency, agency_name FROM stg_311;

CREATE TABLE dim_complaint (
    complaint_key  INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    complaint_type TEXT NOT NULL,
    descriptor     TEXT NOT NULL,
    UNIQUE (complaint_type, descriptor)
);
INSERT INTO dim_complaint (complaint_type, descriptor)
SELECT DISTINCT complaint_type, descriptor FROM stg_311;

CREATE TABLE dim_location (
    location_key    INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    borough         TEXT NOT NULL,
    incident_zip    TEXT NOT NULL,
    community_board TEXT NOT NULL,
    location_type   TEXT NOT NULL,
    UNIQUE (borough, incident_zip, community_board, location_type)
);
INSERT INTO dim_location (borough, incident_zip, community_board, location_type)
SELECT DISTINCT borough, incident_zip, community_board, location_type FROM stg_311;

CREATE TABLE dim_channel (
    channel_key INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    channel     TEXT NOT NULL UNIQUE
);
INSERT INTO dim_channel (channel)
SELECT DISTINCT open_data_channel_type FROM stg_311;

-- ---------- Fact ----------
CREATE TABLE fact_requests (
    unique_key     BIGINT PRIMARY KEY,
    date_key       INT       NOT NULL REFERENCES dim_date,
    created_ts     TIMESTAMP NOT NULL,
    closed_ts      TIMESTAMP,
    agency_key     INT       NOT NULL REFERENCES dim_agency,
    complaint_key  INT       NOT NULL REFERENCES dim_complaint,
    location_key   INT       NOT NULL REFERENCES dim_location,
    channel_key    INT       NOT NULL REFERENCES dim_channel,
    status         TEXT      NOT NULL,
    is_closed      BOOLEAN   NOT NULL,
    response_hours NUMERIC(12,2)
);

INSERT INTO fact_requests
SELECT
    s.unique_key,
    to_char(s.created_date, 'YYYYMMDD')::INT,
    s.created_date,
    s.closed_date,
    a.agency_key,
    c.complaint_key,
    l.location_key,
    ch.channel_key,
    s.status,
    s.is_closed,
    s.response_hours
FROM stg_311 s
JOIN dim_agency    a  ON a.agency = s.agency AND a.agency_name = s.agency_name
JOIN dim_complaint c  ON c.complaint_type = s.complaint_type AND c.descriptor = s.descriptor
JOIN dim_location  l  ON l.borough = s.borough AND l.incident_zip = s.incident_zip
                     AND l.community_board = s.community_board AND l.location_type = s.location_type
JOIN dim_channel   ch ON ch.channel = s.open_data_channel_type;

-- Indexes that the analysis queries lean on
CREATE INDEX ix_fact_date      ON fact_requests (date_key);
CREATE INDEX ix_fact_agency    ON fact_requests (agency_key);
CREATE INDEX ix_fact_complaint ON fact_requests (complaint_key);
CREATE INDEX ix_fact_location  ON fact_requests (location_key);

ANALYZE;
