# NYC 311 Service Requests: Support Operations Analytics

End-to-end analysis of New York City's 311 service requests (a large public customer-support dataset),
built with **Python, Power Query, Excel, SQL (PostgreSQL) and Power BI**.

> Data: [NYC Open Data, 311 Service Requests](https://data.cityofnewyork.us/resource/erm2-nwe9), pulled through the public API.
> Public data only. No employer or client information.

## Questions this project answers
- Which complaint types and agencies generate the most volume?
- How fast does each agency actually close requests (median and 90th percentile, not just averages)?
- What share of requests miss a 72-hour service target?
- When and where does demand spike, and which channels are growing?

## Key findings
_Fill this in after you run the analysis (3-5 bullets with real numbers, e.g. "Agency X's median close time is Y hours vs Z overall")._

## What each tool does
| Tool | Role | Folder |
|---|---|---|
| Python | API extraction, cleaning, exploratory charts, database loading | `python/` |
| Power Query | Repeatable cleaning of the raw file (M code) feeding the Excel data model | `power_query/` |
| Excel | Pivot dashboard with slicers on the cleaned data | `excel/` |
| SQL (PostgreSQL) | Star schema, CTEs, window functions, percentiles, SLA analysis | `sql/` |
| Power BI | Data model, DAX measures, interactive dashboard | `powerbi/` |

## Data model (star schema)
`fact_requests` joined to `dim_date`, `dim_agency`, `dim_complaint`, `dim_location`, `dim_channel`.

## Dashboards
_Add screenshots here: `images/powerbi_overview.png`, `images/excel_dashboard.png`._

## Run it yourself
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt

python python/pull_data.py          # downloads raw data (default: Jan-Mar 2025, up to 1M rows)
python python/clean.py              # cleans data, writes data/clean/ and a 5,000-row sample
python python/eda.py                # saves charts to images/
python python/load_to_postgres.py   # needs a PostgreSQL database named nyc311
```
Then run `sql/03_analysis.sql` in pgAdmin, open Power BI (see `powerbi/model_and_dax.md`),
and load `power_query/01_nyc311_clean.m` in Excel (Data > Get Data > Blank Query > Advanced Editor).

Large files are not committed. `data/sample/nyc311_sample.csv` is a 5,000-row sample so the repo is explorable without running anything.

## Data-quality decisions
- Duplicate `unique_key` rows removed; rows without a created date dropped.
- Requests closed before they were created (data errors) have their response time blanked, not deleted.
- `Unspecified` borough and blank categories become `Unknown`; ZIPs reduced to 5 digits; out-of-city coordinates blanked.
- Excel's grid holds ~1.05M rows, so Excel works from the Data Model (Power Query) or a 500k-row sample; the full data lives in PostgreSQL and Power BI.
