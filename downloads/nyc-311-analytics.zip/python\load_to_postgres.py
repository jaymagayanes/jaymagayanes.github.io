"""
Load data/clean/nyc311_clean.csv into PostgreSQL (fast COPY) and build the star schema.

Connection settings come from environment variables so no password is stored in code:
    PGHOST (default localhost)  PGPORT (5432)  PGUSER (postgres)
    PGDATABASE (nyc311)         PGPASSWORD (asked for if not set)

Usage
    python python/load_to_postgres.py
"""
import csv
import getpass
import os
from pathlib import Path

import psycopg

CSV_PATH = Path("data/clean/nyc311_clean.csv")
SQL_DIR = Path("sql")


def main():
    password = os.environ.get("PGPASSWORD") or getpass.getpass("PostgreSQL password: ")
    conn = psycopg.connect(
        host=os.environ.get("PGHOST", "localhost"),
        port=os.environ.get("PGPORT", "5432"),
        user=os.environ.get("PGUSER", "postgres"),
        dbname=os.environ.get("PGDATABASE", "nyc311"),
        password=password,
        autocommit=True,
    )
    with conn, conn.cursor() as cur:
        print("Creating staging table...")
        cur.execute((SQL_DIR / "01_staging.sql").read_text())

        with CSV_PATH.open(newline="", encoding="utf-8") as f:
            columns = next(csv.reader(f))
        copy_sql = (f"COPY stg_311 ({', '.join(columns)}) "
                    "FROM STDIN WITH (FORMAT csv, HEADER true)")
        print("Loading CSV with COPY (this can take a minute)...")
        with CSV_PATH.open("rb") as f, cur.copy(copy_sql) as copy:
            while chunk := f.read(1 << 20):
                copy.write(chunk)
        cur.execute("SELECT COUNT(*) FROM stg_311")
        print(f"  stg_311 rows: {cur.fetchone()[0]:,}")

        print("Building star schema...")
        cur.execute((SQL_DIR / "02_star_schema.sql").read_text())
        cur.execute("SELECT COUNT(*) FROM fact_requests")
        print(f"  fact_requests rows: {cur.fetchone()[0]:,}")
    print("Done. Open pgAdmin and run sql/03_analysis.sql.")


if __name__ == "__main__":
    main()
