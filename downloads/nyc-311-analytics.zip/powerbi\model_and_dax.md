# Power BI model and DAX

## 1. Connect
**Get data > PostgreSQL database** (server `localhost`, database `nyc311`, mode **Import**).
Select: `fact_requests`, `dim_date`, `dim_agency`, `dim_complaint`, `dim_location`, `dim_channel`.
(If Power BI asks for the Npgsql provider, install it from the link it shows, then restart Power BI.
Fallback: **Get data > Text/CSV** with `data/clean/nyc311_clean.csv`.)

## 2. Relationships (Model view): all many-to-one, single direction, dimension -> fact
| From (one) | To (many) |
|---|---|
| dim_date[date_key] | fact_requests[date_key] |
| dim_agency[agency_key] | fact_requests[agency_key] |
| dim_complaint[complaint_key] | fact_requests[complaint_key] |
| dim_location[location_key] | fact_requests[location_key] |
| dim_channel[channel_key] | fact_requests[channel_key] |

Right-click `dim_date` > **Mark as date table** > choose `full_date`.
Hide the key columns in the fact table so report users only see measures and dimension fields.

## 3. Measures (create a table called `_Measures` and put these in it)
```dax
Total Requests = COUNTROWS ( fact_requests )

Closed Requests = CALCULATE ( [Total Requests], fact_requests[is_closed] = TRUE () )

Open Requests = [Total Requests] - [Closed Requests]

Closure Rate = DIVIDE ( [Closed Requests], [Total Requests] )

Avg Response Hours = AVERAGE ( fact_requests[response_hours] )

Median Response Hours = MEDIAN ( fact_requests[response_hours] )

P90 Response Hours = PERCENTILE.INC ( fact_requests[response_hours], 0.9 )

Pct Over 72h =
DIVIDE (
    CALCULATE ( [Total Requests], fact_requests[response_hours] > 72 ),
    CALCULATE ( [Total Requests], fact_requests[response_hours] <> BLANK () )
)

Requests Prior Month =
CALCULATE ( [Total Requests], DATEADD ( dim_date[full_date], -1, MONTH ) )

MoM % Change = DIVIDE ( [Total Requests] - [Requests Prior Month], [Requests Prior Month] )

Rolling 3M Requests =
CALCULATE (
    [Total Requests],
    DATESINPERIOD ( dim_date[full_date], MAX ( dim_date[full_date] ), -3, MONTH )
)

Share of All Requests =
DIVIDE ( [Total Requests], CALCULATE ( [Total Requests], ALL ( dim_complaint ) ) )
```
Format `Closure Rate`, `Pct Over 72h`, `MoM % Change`, `Share of All Requests` as percentages.

## 4. Suggested report pages
1. **Overview** - KPI cards (Total, Closure Rate, Median Response Hours, Pct Over 72h), monthly volume line with Rolling 3M, top complaint types bar, slicers for borough / agency / date.
2. **Agency performance** - table or bar of Median and P90 hours by agency, Pct Over 72h, with a tooltip page showing the monthly trend.
3. **Where and when** - map (latitude/longitude or borough filled map) plus a weekday x hour matrix (use `dim_date[day_name]` and a created-hour field).

Save as `powerbi/nyc311_dashboard.pbix` and export 2-3 screenshots to `images/`.
