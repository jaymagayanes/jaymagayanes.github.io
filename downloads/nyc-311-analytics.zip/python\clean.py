"""
Clean the raw 311 extract and write analysis-ready files.

Outputs
    data/clean/nyc311_clean.csv        full cleaned data (feeds PostgreSQL + Power BI)
    data/clean/nyc311_excel.csv        up to 500k rows (fits Excel's 1,048,576-row limit)
    data/sample/nyc311_sample.csv      5,000 rows, small enough to commit to GitHub
    data/clean/quality_report.txt      what was fixed / dropped
"""
from pathlib import Path

import pandas as pd

RAW = Path("data/raw/nyc311_raw.csv")
CLEAN = Path("data/clean/nyc311_clean.csv")
EXCEL = Path("data/clean/nyc311_excel.csv")
SAMPLE = Path("data/sample/nyc311_sample.csv")
REPORT = Path("data/clean/quality_report.txt")

CATEGORICAL = ["agency", "agency_name", "complaint_type", "descriptor", "location_type",
               "borough", "community_board", "status", "resolution_description",
               "open_data_channel_type"]


def main():
    df = pd.read_csv(RAW, dtype=str, keep_default_na=False, na_values=[""])
    log = [f"Raw rows: {len(df):,}"]

    # Types
    df["unique_key"] = pd.to_numeric(df["unique_key"], errors="coerce")
    df["created_date"] = pd.to_datetime(df["created_date"], errors="coerce")
    df["closed_date"] = pd.to_datetime(df["closed_date"], errors="coerce")
    df["latitude"] = pd.to_numeric(df["latitude"], errors="coerce")
    df["longitude"] = pd.to_numeric(df["longitude"], errors="coerce")

    # Drop unusable rows
    before = len(df)
    df = df.dropna(subset=["unique_key", "created_date"])
    log.append(f"Dropped {before - len(df):,} rows with no key or created_date")
    before = len(df)
    df = df.drop_duplicates(subset="unique_key")
    log.append(f"Dropped {before - len(df):,} duplicate unique_key rows")
    df["unique_key"] = df["unique_key"].astype("int64")

    # Text standardising
    for col in CATEGORICAL:
        df[col] = df[col].str.strip()
    df["borough"] = df["borough"].str.title().replace({"Unspecified": None})
    df["complaint_type"] = df["complaint_type"].str.title()
    df["agency_name"] = df["agency_name"].str.title()
    zip5 = df["incident_zip"].fillna("").str.extract(r"^(\d{5})")[0]
    df["incident_zip"] = zip5

    # Response time (hours). Closed-before-created is a data error, so blank it out.
    hours = (df["closed_date"] - df["created_date"]).dt.total_seconds() / 3600
    bad = hours < 0
    log.append(f"Set {int(bad.sum()):,} negative response times (closed before created) to blank")
    df["response_hours"] = hours.where(~bad).round(2)
    df["is_closed"] = df["status"].eq("Closed")

    # Missing categories become 'Unknown' so SQL joins never hit NULLs
    for col in CATEGORICAL + ["incident_zip"]:
        df[col] = df[col].fillna("Unknown")

    # Coordinates outside NYC's rough bounding box are errors
    off = ~df["latitude"].between(40.4, 41.0) | ~df["longitude"].between(-74.3, -73.6)
    df.loc[off, ["latitude", "longitude"]] = pd.NA

    df = df.sort_values("created_date")
    log.append(f"Clean rows: {len(df):,}")
    log.append(f"Date range: {df['created_date'].min()} -> {df['created_date'].max()}")
    log.append(f"Median response (closed): {df['response_hours'].median():.1f} hours")

    fmt = dict(index=False, date_format="%Y-%m-%d %H:%M:%S")
    CLEAN.parent.mkdir(parents=True, exist_ok=True)
    SAMPLE.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(CLEAN, **fmt)
    df.sample(n=min(500_000, len(df)), random_state=42).sort_values("created_date").to_csv(EXCEL, **fmt)
    df.sample(n=min(5_000, len(df)), random_state=42).sort_values("created_date").to_csv(SAMPLE, **fmt)
    REPORT.write_text("\n".join(log), encoding="utf-8")
    print("\n".join(log))


if __name__ == "__main__":
    main()
