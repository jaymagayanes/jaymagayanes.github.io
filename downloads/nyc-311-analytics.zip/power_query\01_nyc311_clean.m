// Query name: nyc311_clean
// Cleans the RAW API extract. Same rules as python/clean.py, built the Power Query way.
// Paste into: Home > Advanced Editor (replace everything), then Close & Load To... > Data Model only.
let
    Source = Csv.Document(
        File.Contents(RawCsvPath),
        [Delimiter = ",", Columns = 16, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]
    ),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),

    // 1. Types
    Typed = Table.TransformColumnTypes(
        Promoted,
        {
            {"unique_key", Int64.Type}, {"created_date", type datetime}, {"closed_date", type datetime},
            {"latitude", type number}, {"longitude", type number}
        },
        "en-US"
    ),

    // 2. Empty strings -> null in the text columns, so "missing" means one thing
    TextCols = {"agency", "agency_name", "complaint_type", "descriptor", "location_type", "incident_zip",
                "borough", "community_board", "status", "resolution_description", "open_data_channel_type"},
    BlanksToNull = Table.ReplaceValue(Typed, "", null, Replacer.ReplaceValue, TextCols),

    // 3. Drop unusable rows and duplicate keys
    HasKeys = Table.SelectRows(BlanksToNull, each [unique_key] <> null and [created_date] <> null),
    Deduped = Table.Distinct(HasKeys, {"unique_key"}),

    // 4. Standardise text
    Trimmed = Table.TransformColumns(
        Deduped,
        List.Transform(TextCols, each {_, (v) => if v = null then null else Text.Trim(v), type nullable text})
    ),
    Proper = Table.TransformColumns(
        Trimmed,
        {
            {"borough", each if _ = null or Text.Upper(_) = "UNSPECIFIED" then null else Text.Proper(_), type nullable text},
            {"complaint_type", each if _ = null then null else Text.Proper(_), type nullable text},
            {"agency_name", each if _ = null then null else Text.Proper(_), type nullable text}
        }
    ),

    // 5. ZIP: keep the first 5 digits, otherwise null
    CleanZip = Table.TransformColumns(
        Proper,
        {{"incident_zip", each
            let digits = if _ = null then "" else Text.Select(_, {"0".."9"})
            in if Text.Length(digits) >= 5 then Text.Start(digits, 5) else null,
          type nullable text}}
    ),

    // 6. Response time in hours; closed-before-created is a data error, so blank it
    AddHours = Table.AddColumn(
        CleanZip, "response_hours",
        each
            if [closed_date] = null then null
            else
                let h = Duration.TotalHours([closed_date] - [created_date])
                in if h < 0 then null else Number.Round(h, 2),
        type nullable number
    ),
    AddClosed = Table.AddColumn(AddHours, "is_closed", each [status] = "Closed", type logical),

    // 7. Missing categories -> "Unknown"
    FillUnknown = Table.ReplaceValue(AddClosed, null, "Unknown", Replacer.ReplaceValue, TextCols),

    // 8. Helper columns for Excel pivots
    AddMonth = Table.AddColumn(FillUnknown, "created_month", each Date.StartOfMonth(DateTime.Date([created_date])), type date),
    AddHour  = Table.AddColumn(AddMonth, "created_hour", each Time.Hour(DateTime.Time([created_date])), Int64.Type),
    AddDow   = Table.AddColumn(AddHour, "created_weekday", each Date.DayOfWeekName(DateTime.Date([created_date])), type text)
in
    AddDow
