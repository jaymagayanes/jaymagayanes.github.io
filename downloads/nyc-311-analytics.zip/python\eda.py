"""
Exploratory analysis: prints key stats and saves charts to images/.
Run after clean.py:  python python/eda.py
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

CLEAN = Path("data/clean/nyc311_clean.csv")
IMG = Path("images")
IMG.mkdir(exist_ok=True)

plt.rcParams.update({"figure.dpi": 130, "axes.spines.top": False, "axes.spines.right": False})
COLOR = "#1B4DDB"


def save(fig, name):
    fig.tight_layout()
    fig.savefig(IMG / name)
    plt.close(fig)
    print(f"saved images/{name}")


def main():
    df = pd.read_csv(CLEAN, parse_dates=["created_date", "closed_date"])
    print(f"{len(df):,} requests, {df['created_date'].min():%Y-%m-%d} to {df['created_date'].max():%Y-%m-%d}")

    # 1. Top complaint types
    top = df["complaint_type"].value_counts().head(10).sort_values()
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.barh(top.index, top.values, color=COLOR)
    ax.set_title("Top 10 complaint types by volume")
    ax.set_xlabel("Requests")
    save(fig, "01_top_complaints.png")

    # 2. Daily volume with 7-day average
    daily = df.set_index("created_date").resample("D").size()
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.plot(daily.index, daily.values, color="#B8C6EE", lw=1, label="Daily")
    ax.plot(daily.index, daily.rolling(7).mean(), color=COLOR, lw=2, label="7-day average")
    ax.set_title("Daily 311 request volume")
    ax.legend(frameon=False)
    save(fig, "02_daily_volume.png")

    # 3. Median response time by agency
    resp = (df.dropna(subset=["response_hours"]).groupby("agency")["response_hours"]
              .agg(["median", "count"]).query("count >= 1000")["median"].sort_values().tail(12))
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.barh(resp.index, resp.values, color=COLOR)
    ax.set_title("Median hours to close, by agency (agencies with 1,000+ closed requests)")
    ax.set_xlabel("Hours")
    save(fig, "03_response_by_agency.png")

    # 4. Hour-of-day x weekday heatmap for all requests
    heat = (df.assign(dow=df["created_date"].dt.dayofweek, hour=df["created_date"].dt.hour)
              .pivot_table(index="dow", columns="hour", values="unique_key", aggfunc="count"))
    fig, ax = plt.subplots(figsize=(9, 3.6))
    im = ax.imshow(heat.values, aspect="auto", cmap="Blues")
    ax.set_yticks(range(7), ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])
    ax.set_xticks(range(0, 24, 3))
    ax.set_xlabel("Hour of day")
    ax.set_title("When are requests created?")
    fig.colorbar(im, ax=ax, label="Requests")
    save(fig, "04_hour_weekday_heatmap.png")

    # 5. Share closed vs open by borough
    b = df[df["borough"] != "Unknown"].groupby("borough")["is_closed"].mean().mul(100).sort_values()
    fig, ax = plt.subplots(figsize=(7, 3.6))
    ax.barh(b.index, b.values, color=COLOR)
    ax.set_xlim(0, 100)
    ax.set_title("% of requests closed, by borough")
    save(fig, "05_closed_by_borough.png")


if __name__ == "__main__":
    main()
