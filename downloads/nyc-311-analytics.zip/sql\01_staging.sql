-- Staging table: a 1:1 landing zone for data/clean/nyc311_clean.csv
DROP TABLE IF EXISTS stg_311 CASCADE;

CREATE TABLE stg_311 (
    unique_key              BIGINT,
    created_date            TIMESTAMP,
    closed_date             TIMESTAMP,
    agency                  TEXT,
    agency_name             TEXT,
    complaint_type          TEXT,
    descriptor              TEXT,
    location_type           TEXT,
    incident_zip            TEXT,
    borough                 TEXT,
    community_board         TEXT,
    status                  TEXT,
    resolution_description  TEXT,
    open_data_channel_type  TEXT,
    latitude                NUMERIC(9,6),
    longitude               NUMERIC(9,6),
    response_hours          NUMERIC(12,2),
    is_closed               BOOLEAN
);
